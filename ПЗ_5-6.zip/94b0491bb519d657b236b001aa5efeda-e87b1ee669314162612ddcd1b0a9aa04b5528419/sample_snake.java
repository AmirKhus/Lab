package sample;public class snake {
}
